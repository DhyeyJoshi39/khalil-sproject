import React, { useEffect, useState } from 'react';
import { supabase, type Profile } from '../lib/supabase';
import { PlusCircle, User } from 'lucide-react';

const ProfileSelector = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProfiles(data || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const createProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Deactivate all other profiles first
      await supabase
        .from('profiles')
        .update({ active: false })
        .eq('active', true);

      // Create new profile
      const { error } = await supabase
        .from('profiles')
        .insert([
          {
            name: newProfileName,
            active: true,
          },
        ]);

      if (error) throw error;

      setNewProfileName('');
      setShowCreateForm(false);
      await fetchProfiles();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const switchProfile = async (profileId: string) => {
    setLoading(true);
    setError(null);

    try {
      // Deactivate current active profile
      await supabase
        .from('profiles')
        .update({ active: false })
        .eq('active', true);

      // Activate selected profile
      const { error } = await supabase
        .from('profiles')
        .update({ active: true })
        .eq('id', profileId);

      if (error) throw error;
      await fetchProfiles();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading && profiles.length === 0) {
    return <div className="text-center">Loading profiles...</div>;
  }

  return (
    <div className="space-y-4">
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {profiles.map((profile) => (
          <button
            key={profile.id}
            onClick={() => switchProfile(profile.id)}
            className={`p-4 rounded-lg border ${
              profile.active
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            } transition-colors duration-200 text-left`}
          >
            <div className="flex items-center space-x-3">
              <div className="bg-gray-200 p-2 rounded-full">
                <User className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <div className="font-medium">{profile.name}</div>
                {profile.active && (
                  <div className="text-sm text-blue-600">Active</div>
                )}
              </div>
            </div>
          </button>
        ))}

        <button
          onClick={() => setShowCreateForm(true)}
          className="p-4 rounded-lg border border-dashed border-gray-300 hover:border-gray-400 transition-colors duration-200 flex items-center justify-center space-x-2"
        >
          <PlusCircle className="w-5 h-5" />
          <span>Create New Profile</span>
        </button>
      </div>

      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Create New Profile</h3>
            <form onSubmit={createProfile} className="space-y-4">
              <div>
                <label
                  htmlFor="profileName"
                  className="block text-sm font-medium text-gray-700"
                >
                  Profile Name
                </label>
                <input
                  type="text"
                  id="profileName"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'Create Profile'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileSelector;
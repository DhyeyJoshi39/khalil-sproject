import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, BarChart2, TrendingUp, Settings, LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';

const Sidebar = () => {
  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="bg-gray-900 text-white w-64 min-h-screen p-4">
      <div className="flex items-center gap-2 mb-8">
        <LayoutDashboard className="w-8 h-8" />
        <h1 className="text-xl font-bold">Analytics Dashboard</h1>
      </div>
      
      <nav className="space-y-2">
        <NavLink
          to="/dashboard"
          className={({ isActive }) =>
            `flex items-center gap-2 p-2 rounded hover:bg-gray-800 transition-colors ${
              isActive ? 'bg-gray-800' : ''
            }`
          }
        >
          <BarChart2 className="w-5 h-5" />
          <span>Overview</span>
        </NavLink>
        
        <NavLink
          to="/analytics"
          className={({ isActive }) =>
            `flex items-center gap-2 p-2 rounded hover:bg-gray-800 transition-colors ${
              isActive ? 'bg-gray-800' : ''
            }`
          }
        >
          <TrendingUp className="w-5 h-5" />
          <span>Analytics</span>
        </NavLink>
        
        <NavLink
          to="/settings"
          className={({ isActive }) =>
            `flex items-center gap-2 p-2 rounded hover:bg-gray-800 transition-colors ${
              isActive ? 'bg-gray-800' : ''
            }`
          }
        >
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </NavLink>
      </nav>
      
      <button
        onClick={handleLogout}
        className="flex items-center gap-2 p-2 rounded hover:bg-gray-800 transition-colors mt-auto absolute bottom-4"
      >
        <LogOut className="w-5 h-5" />
        <span>Logout</span>
      </button>
    </div>
  );
};

export default Sidebar;